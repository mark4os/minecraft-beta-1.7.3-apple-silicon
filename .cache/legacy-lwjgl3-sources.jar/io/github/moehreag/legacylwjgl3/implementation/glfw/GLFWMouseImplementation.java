package io.github.moehreag.legacylwjgl3.implementation.glfw;

import io.github.moehreag.legacylwjgl3.implementation.input.MouseImplementation;
import org.lwjgl.glfw.*;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.EventQueue;

import java.nio.ByteBuffer;
import java.nio.DoubleBuffer;

public class GLFWMouseImplementation implements MouseImplementation {
    protected GLFWMouseButtonCallback buttonCallback;
    private GLFWCursorPosCallback posCallback;
    private GLFWScrollCallback scrollCallback;
    private GLFWCursorEnterCallback cursorEnterCallback;
    private long windowHandle;
    private boolean grabbed;
    private boolean isInsideWindow;

    private final EventQueue event_queue = new EventQueue(Mouse.EVENT_SIZE);

    private final ByteBuffer tmp_event = ByteBuffer.allocate(Mouse.EVENT_SIZE);

    private double last_x;
    private double last_y;
    private double accum_dx;
    private double accum_dy;
    private double accum_dz;
    protected byte[] button_states = new byte[this.getButtonCount()];

	@Override
    public void createMouse() {
        this.windowHandle = Display.getHandle();

        if (GLFW.glfwRawMouseMotionSupported() && !Mouse.getPrivilegedBoolean("org.lwjgl.input.Mouse.disableRawInput"))
            GLFW.glfwSetInputMode(this.windowHandle, GLFW.GLFW_RAW_MOUSE_MOTION, GLFW.GLFW_TRUE);

        this.buttonCallback = GLFWMouseButtonCallback.create((window, button, action, mods) -> {
            byte state = action == GLFW.GLFW_PRESS ? (byte)1 : (byte)0;
            putMouseEvent((byte) button, state, 0, System.nanoTime());
            if (button < button_states.length)
                button_states[button] = state;
        });
        this.posCallback = GLFWCursorPosCallback.create((window, xpos, ypos) -> {
            float scale = Display.getPixelScaleFactor();
            int x = (int) (xpos * scale);
            // LWJGL2: (0, 0) = the bottom-left corner
            // GLFW: (0, 0) = the top-left corner
            int y = (int) ((Display.getScreenHeight() - ypos) * scale);
            double dx = x - last_x;
            double dy = y - last_y;
            if (dx != 0 || dy != 0) {
                accum_dx += dx;
                accum_dy += dy;
                last_x = x;
                last_y = y;
                long nanos = System.nanoTime();
                if (grabbed) {
                    putMouseMotionEvent(dx, dy, nanos);
                } else {
                    putMouseMotionEvent(x, y, nanos);
                }
            }
        });
        this.scrollCallback = GLFWScrollCallback.create((window, xoffset, yoffset) -> {
            accum_dz += yoffset;
            putMouseEvent((byte)-1, (byte)0, (int) yoffset, System.nanoTime());
        });
        this.cursorEnterCallback = GLFWCursorEnterCallback.create((window, entered) -> this.isInsideWindow = entered);

        GLFW.glfwSetMouseButtonCallback(this.windowHandle, this.buttonCallback);
        GLFW.glfwSetCursorPosCallback(this.windowHandle, this.posCallback);
        GLFW.glfwSetScrollCallback(this.windowHandle, this.scrollCallback);
        GLFW.glfwSetCursorEnterCallback(this.windowHandle, this.cursorEnterCallback);
    }

    protected void putMouseEvent(byte button, byte state, int dz, long nanos) {
        if (grabbed)
            putMouseEventWithCoords(button, state, 0, 0, dz, nanos);
        else
            putMouseEventWithCoords(button, state, last_x, last_y, dz, nanos);
    }

    protected void putMouseEventWithCoords(byte button, byte state, double coord1, double coord2, int dz, long nanos) {
        tmp_event.clear();
        tmp_event.put(button).put(state).putDouble(coord1).putDouble(coord2).putDouble(dz).putLong(nanos);
        tmp_event.flip();
        event_queue.putEvent(tmp_event);
	}

    private void putMouseMotionEvent(double coord1, double coord2, long nanos) {
        synchronized (event_queue) {
            if (event_queue.hasEvents()) {
                ByteBuffer lastEvent = event_queue.getLastEvent();
                if (lastEvent.get(0) == -1 && lastEvent.getDouble(18) == 0) {
                    if (grabbed) {
                        lastEvent.putDouble(2, lastEvent.getDouble(2) + coord1);
                        lastEvent.putDouble(10, lastEvent.getDouble(10) + coord2);
                    } else {
                        lastEvent.putDouble(2, coord1);
                        lastEvent.putDouble(10, coord2);
                    }
                    lastEvent.putLong(26, nanos);
                    return;
                }
            }

            putMouseEventWithCoords((byte) -1, (byte) 0, coord1, coord2, 0, nanos);
        }
    }

    @Override
    public void destroyMouse() {
        this.buttonCallback.free();
        this.posCallback.free();
        this.scrollCallback.free();
        this.cursorEnterCallback.free();
    }

    private void reset() {
        this.event_queue.clearEvents();
        accum_dx = accum_dy = 0;
    }
    @Override
    public void pollMouse(DoubleBuffer coord_buffer, ByteBuffer buttons_buffer) {
        if (grabbed) {
            coord_buffer.put(0, accum_dx);
            coord_buffer.put(1, accum_dy);
        } else {
            coord_buffer.put(0, last_x);
            coord_buffer.put(1, last_y);
        }
        coord_buffer.put(2, accum_dz);
        accum_dx = accum_dy = accum_dz = 0;
        for (int i = 0; i < button_states.length; i++)
            buttons_buffer.put(i, button_states[i]);
    }

    @Override
    public void readMouse(ByteBuffer readBuffer) {
        event_queue.copyEvents(readBuffer);
    }

    @Override
    public void setCursorPosition(double x, double y) {
        float scale = Display.getPixelScaleFactor();
        this.last_x = x;
        this.last_y = y;
        GLFW.glfwSetCursorPos(this.windowHandle, x / scale, y / scale);
    }

    @Override
    public void grabMouse(boolean grab) {
        GLFW.glfwSetInputMode(this.windowHandle, GLFW.GLFW_CURSOR, grab ? GLFW.GLFW_CURSOR_DISABLED : GLFW.GLFW_CURSOR_NORMAL);
        if (!grab) {
            setCursorPosition(last_x, last_y);
        }
        this.grabbed = grab;
        this.reset();
    }

    @Override
    public boolean hasWheel() {
        return true;
    }

    @Override
    public int getButtonCount() {
        return GLFW.GLFW_MOUSE_BUTTON_LAST + 1;
    }

    @Override
    public boolean isInsideWindow() {
        return grabbed || isInsideWindow;
    }
}