package io.github.moehreag.legacylwjgl3.mixin;

import io.github.moehreag.legacylwjgl3.implementation.LegacyLWJGL3RenderHelper;
import net.ornithemc.osl.lifecycle.impl.client.MinecraftAccess;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@SuppressWarnings({"unused", "UnusedMixin"})
@Mixin(LegacyLWJGL3RenderHelper.class)
public abstract class LegacyLWJGL3RenderHelperBindOldMixin {
	/**
	 * @author moehreag
	 * @reason implement cross-version access
	 */
	@Overwrite
	public static void blitPreeditBackground(int texWidth, int texHeight, int u, int v, int x, int y, int width, int height) {
		GL11.glBindTexture(GL11.GL_TEXTURE_2D, MinecraftAccess.getInstance().f_45465196.m_33729172("/assets/legacy-lwjgl3/textures/preedit.png"));
		LegacyLWJGL3RenderHelper.blit(texWidth, texHeight, u, v, x, y, width, height);
	}
}
